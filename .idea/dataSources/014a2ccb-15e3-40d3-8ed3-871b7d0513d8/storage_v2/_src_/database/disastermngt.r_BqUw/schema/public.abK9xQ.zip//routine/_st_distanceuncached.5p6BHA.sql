create function "_st_distanceuncached"(geography, geography, boolean) returns double precision
  immutable
  strict
  language sql
as
$$
SELECT _ST_DistanceUnCached($1, $2, 0.0, $3)
$$;

alter function "_st_distanceuncached"(geography, geography, boolean) owner to postgres;

