create function geometry_raster_overlap(geometry, raster) returns boolean
  immutable
  strict
  language sql
as
$$
select $1 && $2::geometry
$$;

alter function geometry_raster_overlap(geometry, raster) owner to postgres;

