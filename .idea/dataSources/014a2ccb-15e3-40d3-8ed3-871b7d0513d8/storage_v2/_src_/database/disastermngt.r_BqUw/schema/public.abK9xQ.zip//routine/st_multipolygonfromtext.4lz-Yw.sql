create function st_multipolygonfromtext(text) returns geometry
  immutable
  strict
  language sql
as
$$
SELECT ST_MPolyFromText($1)
$$;

alter function st_multipolygonfromtext(text) owner to postgres;

