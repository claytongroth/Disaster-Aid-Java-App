create function st_covers(text, text) returns boolean
  immutable
  language sql
as
$$
SELECT ST_Covers($1::geometry, $2::geometry);
$$;

alter function st_covers(text, text) owner to postgres;

