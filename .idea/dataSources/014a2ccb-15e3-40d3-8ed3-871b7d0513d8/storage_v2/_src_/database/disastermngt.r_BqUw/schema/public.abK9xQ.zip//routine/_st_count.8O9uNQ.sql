create function "_st_count"(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 1) returns bigint
  stable
  strict
  language plpgsql
as
$$
DECLARE
		count bigint;
	BEGIN
		EXECUTE 'SELECT ST_CountAgg('
			|| quote_ident($2) || ', '
			|| $3 || ', '
			|| $4 || ', '
			|| $5 || ') '
			|| 'FROM ' || quote_ident($1)
	 	INTO count;
		RETURN count;
	END;

$$;

alter function "_st_count"(text, text, integer, boolean, double precision) owner to postgres;

