create function st_covers(geography, geography) returns boolean
  immutable
  language sql
as
$$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$;

comment on function st_covers(geography, geography) is 'args: geogpolyA, geogpointB - Returns 1 (TRUE) if no point in Geometry B is outside Geometry A';

alter function st_covers(geography, geography) owner to postgres;

