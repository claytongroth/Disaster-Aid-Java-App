create function st_within(geom1 geometry, geom2 geometry) returns boolean
  immutable
  language sql
as
$$
SELECT $2 ~ $1 AND _ST_Contains($2,$1)
$$;

comment on function st_within(geometry, geometry) is 'args: A, B - Returns true if the geometry A is completely inside geometry B';

alter function st_within(geometry, geometry) owner to postgres;

