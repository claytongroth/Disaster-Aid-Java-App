create function raster_eq(raster, raster) returns boolean
  immutable
  strict
  language sql
as
$$
SELECT raster_hash($1) = raster_hash($2)
$$;

alter function raster_eq(raster, raster) owner to postgres;

