create function st_approxcount(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1) returns bigint
  stable
  strict
  language sql
as
$$
SELECT _st_count($1, $2, $3, $4, $5)
$$;

alter function st_approxcount(text, text, integer, boolean, double precision) owner to postgres;

