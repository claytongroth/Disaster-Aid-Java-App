create function st_histogram(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, bins integer DEFAULT 0, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
  stable
  language sql
as
$$
SELECT _st_histogram($1, $2, $3, $4, 1, $5, $6, $7)
$$;

comment on function st_histogram(text, text, integer, boolean, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) is 'args: rastertable, rastercolumn, nband=1, exclude_nodata_value=true, bins=autocomputed, width=NULL, right=false - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(text, text, integer, boolean, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) owner to postgres;

