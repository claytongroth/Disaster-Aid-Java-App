create function checkauth(text, text) returns integer
  language sql
as
$$
SELECT CheckAuth('', $1, $2)
$$;

comment on function checkauth(text, text) is 'args: a_table_name, a_key_column_name - Creates trigger on a table to prevent/allow updates and deletes of rows based on authorization token.';

alter function checkauth(text, text) owner to postgres;

