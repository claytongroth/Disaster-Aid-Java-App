create function st_asgeojson(text) returns text
  immutable
  strict
  language sql
as
$$
SELECT _ST_AsGeoJson(1, $1::geometry,15,0);
$$;

alter function st_asgeojson(text) owner to postgres;

