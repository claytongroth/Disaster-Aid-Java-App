create function st_stddev4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) returns double precision
  immutable
  language sql
as
$$
SELECT stddev(unnest) FROM unnest($1)
$$;

alter function st_stddev4ma(double precision[], text, text[]) owner to postgres;

